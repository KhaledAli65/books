# -*- coding: utf-8 -*-
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.Console import Console
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.Label import Label
from Tools.Directories import fileExists
import os

class RestoreBackupScreen(Screen):
    skin = """
    <screen name="RestoreBackupScreen" position="center,center" size="650,480" title="Khaled Restore Backup Tool">
        <widget name="status" position="20,20" size="610,120" font="Regular;18" foregroundColor="#00ffc000" />
        <widget name="info" position="20,150" size="610,300" font="Regular;16" />
    </screen>"""

    def __init__(self, session):
        self.session = session
        Screen.__init__(self, session)
        
        self["status"] = Label("جاهز لاستعادة ملف rootfs.tar.bz2 بنظام الكونسول الاحترافي")
        self["info"] = Label("اضغط على زر OK لإيقاف الإنجيما وبدء الاستعادة الفورية مع تتبع المخرجات.")
        
        self["actions"] = ActionMap(["SetupActions", "ColorActions"], {
            "ok": self.askRestore,
            "cancel": self.close
        }, -2)

    def askRestore(self):
        self.session.openWithCallback(
            self.confirmRestoreCallback, 
            MessageBox, 
            "تحذير: سيتم إيقاف واجهة Enigma2 وبث القنوات، والكتابة فوق النظام بالكامل.\nهل تريد المتابعة حقاً؟", 
            MessageBox.TYPE_YESNO, 
            default=False
        )

    def confirmRestoreCallback(self, result):
        if result:
            self.startConsoleRestore()
        else:
            self["status"].setText("تم إلغاء العملية.")

    def startConsoleRestore(self):
        self["status"].setText("جاري تجهيز مسار النسخة الاحتياطية...")
        
        possible_paths = [
            "/media/hdd/rootfs.tar.bz2",
            "/media/usb/rootfs.tar.bz2",
            "/media/sda1/rootfs.tar.bz2"
        ]
        
        backup_path = None
        for path in possible_paths:
            if fileExists(path):
                backup_path = path
                break
                
        if not backup_path:
            self.session.open(MessageBox, "خطأ: لم يتم العثور على ملف rootfs.tar.bz2 في مسارات الهارد أو الفلاش!", MessageBox.TYPE_ERROR)
            return

        # أمر التنفيذ المتكامل والآمن عبر الكونسول:
        # 1. إيقاف واجهة الإنجيما لمنع تعارض الملفات (Device busy)
        # 2. فك الضغط المباشر مع صلاحيات الكتابة الكاملة والاستبدال الجذري فوق القديم (-p, -o)
        # 3. إعادة تشغيل الجهاز تلقائياً بعد الانتهاء بنجاح
        cmd = f"echo '==> Stopping Enigma2 and starting restore...'; killall -9 enigma2; bzip2 -dc {backup_path} | tar -x -p -o -C /; echo '==> Restore finished! Rebooting now...'; reboot"

        self.session.open(Console, title="Khaled Terminal - Restoring System...", cmdList=[cmd])

def main(session, **kwargs):
    session.open(RestoreBackupScreen)

def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name="Khaled Restore Backup", 
            description="أداة استعادة ملف rootfs بالكونسول", 
            where=PluginDescriptor.WHERE_PLUGINMENU, 
            icon="plugin.png", 
            fnc=main
        )
    ]

